"""AreaForge data modeling helpers."""
