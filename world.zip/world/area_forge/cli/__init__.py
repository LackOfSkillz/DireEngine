"""CLI entrypoints for AreaForge."""
