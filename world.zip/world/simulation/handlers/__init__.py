"""Persistent simulation handlers."""
