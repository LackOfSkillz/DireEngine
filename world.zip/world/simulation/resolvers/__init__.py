"""DireSim resolver package."""
